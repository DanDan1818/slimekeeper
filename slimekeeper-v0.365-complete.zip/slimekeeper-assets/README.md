# Slime Keeper Assets

This folder contains all images and assets for Slime Keeper.

## Directory Structure

```
slimekeeper-v0.352.html          ← Main game file
slimekeeper-assets/
  ├── images/
  │   └── slime.png               ← Slime character image
  └── README.md                   ← This file
```

## How to Use

1. Keep the HTML file and `slimekeeper-assets` folder **in the same directory**
2. The HTML references images using relative paths: `./slimekeeper-assets/images/`
3. Add new images to the `images/` folder
4. Reference them in the HTML as: `./slimekeeper-assets/images/your-image.png`

## Adding New Images

Just copy/paste new images into the `images/` folder and reference them in the code:

```css
background-image: url('./slimekeeper-assets/images/your-image.png');
```

Or in HTML:
```html
<img src="./slimekeeper-assets/images/your-image.png">
```

## Benefits

✅ **Small HTML file** - no embedded base64 bloat
✅ **Easy to update** - just replace image files
✅ **Scalable** - add as many images as needed
✅ **Organized** - all assets in one place
✅ **Browser cached** - images load faster after first visit

## Current Images

**Slimes (5 variants - randomly selected on hatch):**
- `slime-blue.png` - Happy blue slime (original) 🔵
- `slime-orange.png` - Angry orange/red slime with determined expression 🔴
- `slime-green.png` - Happy green slime with cheerful face 🟢
- `slime-yellow.png` - Happy yellow slime with star eyes ⭐
- `slime-pink.png` - Happy pink slime with cute expression 🩷

Each slime has a 20% chance (1 in 5) of being selected when you hatch!
